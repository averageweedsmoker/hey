import requests
from bs4 import BeautifulSoup
import time
import threading

def search_and_extract_links(keyword, output_file):
    search_url = f"https://www.ask.com/web?q={keyword}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }

    for page in range(1, 11):
        while True:
            try:
                response = requests.get(search_url, headers=headers, params={"page": page})
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')
                for link in soup.find_all('a', class_='PartialSearchResults-item-title-link'):
                    href = link.get('href')
                    if href:
                        with open(output_file, 'a') as file:
                            file.write(href + '\n')
                        print(href)
                break
            except Exception as e:
                print(f"An error occurred while searching for '{keyword}' on page {page}: {str(e)}")
                continue
        if not href:
            print(f"No more links found for '{keyword}' on page {page}. Moving to the next keyword.")
            break

def send_file_to_telegram(file_path, token, chat_id):
    while True:
        url = f"https://api.telegram.org/bot{token}/sendDocument"
        with open(file_path, 'rb') as file:
            payload = {'chat_id': chat_id}
            files = {'document': file}
            requests.post(url, data=payload, files=files)
        print("File sent to Telegram. Waiting for the next iteration...")
        time.sleep(3600)  # Wait for 1 minute

# Your Telegram Bot token and chat ID
telegram_token = "6529399477:AAE9mrY-OaKv19nK1BIOCokCIwXQtTCp0w4"
telegram_chat_id = "5733643214"

# Output file to save the URLs
output_file = 'urls.txt'

# Create a thread for sending files to Telegram
telegram_thread = threading.Thread(target=send_file_to_telegram, args=(output_file, telegram_token, telegram_chat_id,))
telegram_thread.daemon = True  # Set the thread as a daemon so it will exit when the main program exits
telegram_thread.start()

# Read keywords from keywords.txt
with open('keywords.txt', 'r') as file:
    keywords = [line.strip() for line in file]

# Search and extract links for each keyword
for keyword in keywords:
    print(f"Searching for '{keyword}'...")
    search_and_extract_links(keyword, output_file)
    print("\n")


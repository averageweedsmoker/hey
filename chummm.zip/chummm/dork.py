import random
import nltk

# Download the NLTK "words" corpus if you haven't already
nltk.download("words")

# Get a list of words from the NLTK corpus of all words
all_word_list = nltk.corpus.words.words()

# Filter for more common words (e.g., those with fewer than 6 characters)
word_list = [word for word in all_word_list if len(word) < 6]

# Read the file extensions from "extensions.txt"
with open("extensions.txt", "r") as extension_file:
    extensions = [line.strip() for line in extension_file]

# Read the file queries from "queries.txt"
with open("queries.txt", "r") as query_file:
    queries = [line.strip() for line in query_file]

# Number of words to use
num_words = 500

# Create a list to store all dorks
dorks = []

# Generate and save all possible dorks with random words
for _ in range(num_words):
    random_word = random.choice(word_list)
    for extension in extensions:
        for query in queries:
            dork = f"{random_word}{extension}{query}"
            dorks.append(dork)

# Save dorks to a text file called "dorks.txt"
with open("dorks.txt", "w") as dorks_file:
    for dork in dorks:
        dorks_file.write(dork + "\n")

# Print all the generated dorks
for dork in dorks:
    print(dork)

